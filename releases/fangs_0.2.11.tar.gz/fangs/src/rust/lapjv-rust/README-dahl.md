# Why a fork?

This is source code of the lapjv crate from https://github.com/Antti/lapjv-rust,
but the dependency on ndarray was old and lead to compatibility issues.  I cloned
that repository and bumped the dependencies.  -- David Dahl



