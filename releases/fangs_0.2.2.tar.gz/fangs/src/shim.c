void R_init_fangs_rust(void *dll);
void R_init_fangs(void *dll) { R_init_fangs_rust(dll); }
