#' @docType package
#' @usage NULL
#' @useDynLib fangs, .registration = TRUE
NULL
