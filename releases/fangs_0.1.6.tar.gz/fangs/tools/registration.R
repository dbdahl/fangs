.Call <- base::.Call
.compute_expected_loss <- NULL
.compute_loss_augmented <- NULL
.compute_loss <- NULL
.compute_loss_permutations <- NULL
.fangs_old <- NULL
.fangs <- NULL
